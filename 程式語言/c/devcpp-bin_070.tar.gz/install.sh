##
## install.sh for Dev-C++
## 
## Made by Colin Laplace
## 
## Started on  Sun Apr 15 05:20:02 2001 colin
## Last update Tue Apr 24 03:03:20 2001 colin
##

yesno ()
{
  while true; do
  echo -n "$1 (Y/n) ? "
  read ans
  case X$ans in
   X|Xy|XY) return 0;;
   Xn|XN) return 1;;
  esac
  done
}

ask ()
{
askvar=$2
eval old=\$$askvar
eval echo -n \""$1 [$old] : "\" 
read $askvar
eval test -z \"\$$askvar\" && eval $askvar=\'$old\'
}

echo "** Dev-C++ installation script **"
echo ""
echo "You must be root to install. Do you want to continue ?"
if yesno; then
    tar xzvf binary.tar.gz
    DEFAULTDIR=$HOME/dev-c++
    ask "Where do you want to install Dev-C++ ?" DEFAULTDIR
    test -d $DEFAULTDIR || mkdir $DEFAULTDIR
    mv TODO $DEFAULTDIR
    mv BUGS $DEFAULTDIR
    mv bin/devcpp $DEFAULTDIR
    mv bin/libqtintf.so* /lib
    echo ""
    echo "* This script will now guess your gcc and make paths"
    echo "* Press enter if the path is correct for each program"
    echo ""
    MAKEDIR=`whereis make | cut -d " " -f2`
    ask "make is located in :" MAKEDIR
    GCCDIR=`whereis gcc | cut -d " " -f2`
    ask "gcc is located in :" GCCDIR
    GPPDIR=`whereis g++ | cut -d " " -f2`
    ask "g++ is located in :" GPPDIR
    GDBDIR=`whereis gdb | cut -d " " -f2`
    ask "gdb (or your favourite debugger) is located in :" GDBDIR
    TERMDIR=`whereis xterm | cut -d " " -f2`
    ask "xterm, aterm or Eterm is located in :" TERMDIR
    echo ""
    CONFDIR=$HOME/.devcpp
    CONF=$CONFDIR/config
    test -d $CONFDIR || mkdir $CONFDIR
    echo "* Configuration file is now been written in $CONF"
    echo ""
    echo "[dev]" > $CONF
    echo "make_dir=$MAKEDIR" >> $CONF
    echo "gcc_dir=$GCCDIR" >> $CONF
    echo "g++_dir=$GPPDIR" >> $CONF
    echo "term_dir=$TERMDIR" >> $CONF
    echo "gdb_dir=$GDBDIR" >> $CONF
    echo ""
    echo "* Installation terminated, you may now run $DEFAULTDIR/devcpp"
    echo ""
fi




