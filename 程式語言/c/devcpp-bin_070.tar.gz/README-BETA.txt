** Inwtructions on reporting bugs **

This Dev-C++ for Linux beta version contains many bugs, it isn't really usable for now. 

If you could report as many bugs as you can i would be very grateful, so here is some information on making a bug report :

- First look in the BUGS file to see if the bug is already known or not
- Include your linux kernel version, as well as distribution.
- Then include the Dev-C++ binary version you used
- Please tell how the bug appeard and how to reproduce it
- Send it as an email at haiku@bloodshed.net

Thank you :)
